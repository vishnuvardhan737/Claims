﻿using ClaimsApp.Models;
using CsvHelper.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClaimsApp.Mapper
{
    public class MemberMapper: ClassMap<Member>
    {
      public MemberMapper()
        {
            Map(m => m.MemberID).Name("MemberID");
            Map(m => m.EnrollmentDate).Name("EnrollmentDate");
            Map(m => m.FirstName).Name("FirstName");
            Map(m => m.LastName).Name("LastName");
        }


    }
}
