﻿using ClaimsApp.Models;
using CsvHelper.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClaimsApp.Mapper
{
    public class ClaimsMapper: ClassMap<Claim>
    {
        public ClaimsMapper()
        {
            Map(m => m.MemberID).Name("MemberID");
            Map(m => m.ClaimDate).Name("ClaimDate");
            Map(m => m.ClaimAmount).Name("ClaimAmount");

        }
    }
}
