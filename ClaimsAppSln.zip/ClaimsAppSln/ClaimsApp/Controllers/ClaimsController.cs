﻿using ClaimsApp.Models;
using ClaimsApp.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClaimsApp.Controllers
{
    
    [Route("api/[controller]")]
    [ApiController]
    public class ClaimsController : ControllerBase
    {
        private IClaimsService _claimsService;
        public ClaimsController(IClaimsService claimsService)
        {
            _claimsService = claimsService;
        }
     

        [HttpGet]
        [Route("ClaimsByDate")]
        public IActionResult Get(DateTime claimDate)
        {
            var model = _claimsService.GetClaimsByDate(claimDate);
            return Ok(model);
        }
    }
}
