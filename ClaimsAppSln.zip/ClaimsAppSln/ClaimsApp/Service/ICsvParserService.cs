﻿using ClaimsApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClaimsApp.Service
{
   public interface ICsvParserService
    {
        List<Claim> ReadCsvFileToClaimModel(string path);
        List<Member> ReadCsvFileToMemberModel(string path);

    }
}
