﻿using ClaimsApp.Mapper;
using ClaimsApp.Models;
using CsvHelper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ClaimsApp.Service
{
    public class CsvParserService : ICsvParserService
    {
        public List<Claim> ReadCsvFileToClaimModel(string path)
        {
            using (var reader = new StreamReader(path, Encoding.Default))
            using (var csv = new CsvReader(reader))
            {
                csv.Configuration.RegisterClassMap<ClaimsMapper>();
                var records = csv.GetRecords<Claim>().ToList();
                return records;
            }
        }

        public List<Member> ReadCsvFileToMemberModel(string path)
        {
            using (var reader = new StreamReader(path, Encoding.Default))
            using (var csv = new CsvReader(reader))
            {
                csv.Configuration.RegisterClassMap<MemberMapper>();
                var records = csv.GetRecords<Member>().ToList();
                return records;
            }
        }
    }
}
