﻿using ClaimsApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClaimsApp.Service
{
    public class ClaimsService : IClaimsService
    {
        string claimPath = @"C:\CSV\Claim.csv";
        string memberPath = @"C:\CSV\Member.csv";

        public ICsvParserService _csvParserService;
        public ClaimsService(ICsvParserService csvParserService)
        {
            _csvParserService = csvParserService;
        }

        public ClaimsMemberModel GetClaimsByDate(DateTime claimDate)
        {
           
            var claims = _csvParserService.ReadCsvFileToClaimModel(claimPath);
            var members = _csvParserService.ReadCsvFileToMemberModel(memberPath);
            ClaimsMemberModel claimsMemberModel = new ClaimsMemberModel();
            var claimsByDate = claims.Where(s => s.ClaimDate <= claimDate).ToList();
            var membersByClaimId = new List<Member>();
            foreach (var item in claimsByDate)
            {
                var member = members.Where(s => s.MemberID == item.MemberID).FirstOrDefault();
                if (member != null)
                {
                    membersByClaimId.Add(member);
                }
            }
            claimsMemberModel.claims = claimsByDate;
            claimsMemberModel.members = membersByClaimId;
            return claimsMemberModel;
        }
    }
}
