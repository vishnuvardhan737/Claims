﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClaimsApp.Models
{
    public class ClaimsMemberModel
    {
        public ClaimsMemberModel()
        {
            claims = new List<Claim>();
            members = new List<Member>();
        }
        public List<Claim> claims { get; set; }
        public List<Member> members { get; set; }

    }
}
