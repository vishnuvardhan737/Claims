﻿using CsvHelper.Configuration.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClaimsApp.Models
{
    public class Claim
    {
        [Name("MemberID")]
        public int MemberID { get; set; }

        [Name("ClaimDate")]
        public DateTime ClaimDate { get; set; }

        [Name("ClaimAmount")]
        public decimal ClaimAmount { get; set; }
    }
}
